# Load necessary library
library(ggplot2)

# Exclude the first row and data management 
library(dplyr)

result_table_subset <- Result[-1, ] %>%
  filter(!is.na(Q1)) %>%
  mutate(Q1 = ifelse(Q1 == 26, 62, Q1))

# Convert Q1 from character to numeric
result_table_subset$Q1 <- as.numeric(result_table_subset$Q1)
library(ggplot2)
#create the box plot

ggplot(result_table_subset, aes(x = "", y = Q1)) +
  geom_boxplot(fill = "lightblue", color = "darkblue", outlier.colour = "red") +
  geom_point(aes(y = mean(Q1, na.rm = TRUE)), color = "orange", size = 3, shape = 18) +
  geom_errorbar(aes(ymin = mean(Q1, na.rm = TRUE) - sd(Q1, na.rm = TRUE), 
                    ymax = mean(Q1, na.rm = TRUE) + sd(Q1, na.rm = TRUE)), 
                width = 0.2, color = "orange") +
  labs(title = "Age Distribution", y = "Age") +
  theme_minimal() +
  theme(axis.title.x = element_blank())




