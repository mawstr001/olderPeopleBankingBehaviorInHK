# Step 3: Filter for "1-5 times" and "6 times or more" frequency and calculate normalized proportions
# Step 3: Filter for "1-5 times" and "6 times or more" frequency and calculate normalized proportions
# Step 3: Filter for "1-5 times" and "6 times or more" frequency and calculate normalized proportions
line_data <- age_channel_relationship %>%
  filter(Frequency %in% c("1-5 times", "6 times or more")) %>%
  group_by(age_grp, Channel) %>%
  summarise(Count = n(), .groups = 'drop') %>%
  complete(age_grp, Channel, fill = list(Count = 0)) %>%  # Fill missing combinations with 0
  group_by(age_grp) %>%
  mutate(Proportion = Count / sum(Count) * 100) %>%  # Convert to percentage
  select(-Count)

# Step 4: Create the line graph
ggplot(line_data, aes(x = age_grp, y = Proportion, group = Channel, color = Channel)) +
  geom_line() +
  geom_point() +
  labs(title = "Proportional Usage of Channels by Age Group (More than 1 Time per Year)",
       x = "Age Group",
       y = "Percentage of Participants",
       color = "Channel") +
  scale_y_continuous(labels = scales::percent_format(scale = 1)) +  # Format y-axis as percentage
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
