library(ggplot2)
library(dplyr)
library(tidyr)

physical_challenges <- data.frame(
  Digit = c(1, 2, 3, 4, 5, 6,7,8,9),
  Description = c(
    "Difficulty reading small print or documents.",
    "Difficulty reading small print or documents.",
    "Difficulty understanding instructions due to hearing issues.",
    "Difficulty transmitting information, such as with bills.",
    "Difficulty transmitting information, such as with bills.",
    "Trouble remembering steps in daily tasks while using a computer.",
    "Trouble remembering the login details.",
    "Discomfort using electronic devices, including wrist or joint pain.",
    "Difficulty accessing electronic information and connecting to the internet."
  )
)

trust_barriers <- data.frame(
  Digit = c(1, 2, 3, 4, 5, 6,7,8,9),
  Description = c(
    "Fear of scam.",
    "Fear of unauthorized users (hackers).",
    "Lack of trust in online banking tools and transactions.",
    "Concerns about data privacy.",
    "Lack of support and feedback",
    "Lack of holistic view",
    "Fear of making mistakes.",
    "Lack of trust in online banking tools and transactions.",
    "Fear of making mistakes."
  )
)

knowledge_barriers <- data.frame(
  Digit = c(1, 2, 3, 4,5,6,7),
  Description = c(
    "Uncertain about online bank services provided",
    "Uncertain about online bank services provided",
    "Limited understanding of technology.",
    "The terminology used is difficult.", 
    "Unfamiliear with security practices",
    "Outdated information",
    "Difficult to undetstand the instructions"
  )
)

# Function to split barriers and create a long format data frame
create_long_format <- function(data, reason_col, category) {
  split_data <- data %>%
    select(Age, all_of(reason_col)) %>%
    pivot_longer(cols = all_of(reason_col), names_to = "Reason", values_to = "Challenges") %>%
    filter(!is.na(Challenges)) %>%
    separate_rows(Challenges, sep = ",") %>%
    mutate(Category = category)
  
  return(split_data)
}

# Function to create long format data
create_long_format <- function(data, category) {
  data_long <- data %>%
    select(Digit, Description) %>%
    mutate(Category = category)
  
  return(data_long)
}

# Create long format data for each barrier category
physical_long <- create_long_format(physical_challenges, "Physical")
trust_long <- create_long_format(trust_barriers, "Trust")
knowledge_long <- create_long_format(knowledge_barriers, "Knowledge")

# Combine all long format data
combined_long <- bind_rows(physical_long, trust_long, knowledge_long)
# Convert Challenges from factor to numeric
final_counts$Challenges <- as.numeric(as.character(final_counts$Challenges))
print(final_counts)
# Create a complete set of categories and challenges
# Create a complete set of Physical challenges
complete_physical_data <- combined_long %>%
  filter(Category == "Physical")
# Merge counts with the complete set of descriptions
merged_physical_data <- complete_physical_data %>%
  left_join(final_counts, by = c("Category", "Digit" = "Challenges")) %>%
  replace_na(list(Count = 0, Percentage = 0))  # Set missing counts to 0

# Select relevant columns for the output table
output_physical_barrier_table <- merged_physical_data %>%
  select(Description, Percentage)

# Print the output table
print(output_physical_barrier_table)
#---------------------------------------------------------------------------------------------#
# Create a complete set of trust challenges
complete_trust_data <- combined_long %>%
  filter(Category == "Trust")
# Merge counts with the complete set of descriptions
merged_trust_data <- complete_physical_data %>%
  left_join(final_counts, by = c("Category", "Digit" = "Challenges")) %>%
  replace_na(list(Count = 0, Percentage = 0))  # Set missing counts to 0

# Select relevant columns for the output table
output_trust_barrier_table <- merged_trust_data %>%
  select(Description, Percentage)

# Print the output table
print(output_trust_barrier_table)
#-----------------------------------------------------------------------------------------------#
final_counts <- final_counts %>%
  mutate(Category = ifelse(Category == "Tech", "Knowledge", Category))
# Create a complete set of knowledge challenges
complete_Knowledge_data <- combined_long %>%
  filter(Category == "Knowledge")
# Merge counts with the complete set of descriptions
merged_Knowledge_data <- complete_Knowledge_data %>%
  left_join(final_counts, by = c("Category", "Digit" = "Challenges")) %>%
  replace_na(list(Count = 0, Percentage = 0))  # Set missing counts to 0
print(merged_Knowledge_data)
# Select relevant columns for the output table
output_Knowledge_barrier_table <- merged_Knowledge_data %>%
  select(Description, Percentage)

# Print the output table
print(output_Knowledge_barrier_table)
