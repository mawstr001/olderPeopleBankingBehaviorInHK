# Create the demographic data frame with Age and Gender
demographic <- banking_usage_no_row2_master0429 %>%
  select(Age, Gender)

# Apply function to create age groups
demographic$age_grp <- sapply(demographic$Age, categorize_age)

Gender_dict <- data.frame(
  Digit = c(1,2,3),
  Description = c(
        "Male",
        "Femal",
        "Not disclosed"
  )
)
demographic$Gender <- as.numeric(as.character(demographic$Gender))
# Merge counts with the complete set of descriptions
# Merge demographic with the gender dictionary
demographic_managed <- demographic %>%
  left_join(Gender_dict, by = c("Gender" = "Digit")) %>%
  select(Age, age_grp, Description)  # Select relevant columns
print(demographic_managed)

age_group_counts <- demographic %>%
  group_by(Gender) %>%
  summarise(Count = n()) %>%
  ungroup()

# Calculate total count for percentage calculation
total_count <- sum(age_group_counts$Count)

# Calculate percentage for each age group
age_group_percentage <- age_group_counts %>%
  mutate(Percentage = (Count / total_count) * 100)

# Print the age group percentage table
print(age_group_percentage)


