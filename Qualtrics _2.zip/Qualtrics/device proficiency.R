# Digital Device Ability 
# Assess their confidence of using digital device

library(dplyr)
library(ggplot2)
library(stringr)

result_table_subset

# Summarize counts, calculate percentages, and translate labels
device_ability <- result_table_subset %>%
  group_by(Q6) %>%
  summarise(Count = n(), .groups = "drop") %>%
  mutate(Percentage = (Count / sum(Count)) * 100,  # Calculate percentage
         Q6 = case_when(
           Q6 == "我不會使用任何科技" ~ "I do not use any technology",
           Q6 == "我只能處理基本科技（例如：發送電子郵件、瀏覽網路）" ~ "I can only handle basic technology (e.g., sending emails, browsing the internet)",
           Q6 == "我只能處理中等水平的科技 （例如：使用 Word 或 Excel 等辦公室軟體，進行基本的故障排除）" ~ "I can only handle intermediate technology (e.g., using office software like Word or Excel, performing basic troubleshooting)",
           Q6 == "我擅長處理科技（例如：使用先進的軟體，解決技術問題）" ~ "I am skilled at handling technology (e.g., using advanced software, solving technical problems)"
         )) %>%
  mutate(Q6 = factor(Q6, levels = c(
    "I do not use any technology", 
    "I can only handle basic technology (e.g., sending emails, browsing the internet)", 
    "I can only handle intermediate technology (e.g., using office software like Word or Excel, performing basic troubleshooting)", 
    "I am skilled at handling technology (e.g., using advanced software, solving technical problems)"
  )))  # Custom order from no proficiency to most efficiency

# Set custom order for Q6
device_ability <- device_ability %>%
  mutate(Q6 = factor(Q6, levels = c(
    "I do not use any technology", 
    "I can only handle basic technology (e.g., sending emails, browsing the internet)", 
    "I can only handle intermediate technology (e.g., using office software like Word or Excel, performing basic troubleshooting)", 
    "I am skilled at handling technology (e.g., using advanced software, solving technical problems)"
  )))  # Custom order from no proficiency to most efficiency


# Rearrange the data frame based on the new factor levels
device_ability <- device_ability %>%
  arrange(Q6)


