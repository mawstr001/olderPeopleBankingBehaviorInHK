# Load necessary libraries
library(ggplot2)
library(dplyr)
library(tidyr)
library(RColorBrewer)
library(reshape2)

barrier <- banking_usage_no_row2_master0429 %>%
              select(Age, 
                      Reason_physical_challenge, 
                     Reason_trust_challenge, 
                     Reason_tech_challenge, 
                     Reason_highest_challenge)
)


# Function to categorize age groups
categorize_age <- function(age) {
  if (age >= 60 && age <= 69) {
    return("young-old")
  } else if (age >= 70 && age <= 79) {
    return("old-old")
  } else if (age >= 80) {
    return("oldest-old")
  } else {
    return(NA)  # Handle ages below 60
  }
}

# Apply function to create age groups
barrier$age_grp <- sapply(barrier$Age, categorize_age)

# Convert age_grp to a factor with specified levels for ordering
barrier$age_grp <- factor(barrier$age_grp, 
                          levels = c("young-old", "old-old", "oldest-old"))

# Map the highest challenge values to their respective barrier types
barrier$Highest_Challenge_Type <- factor(barrier$Reason_highest_challenge,
                                         levels = c(1, 2, 3),
                                         labels = c("Physical", "Trust", "Knowledge"))
# Summarize the data to calculate the percentage of each challenge type by age group
barrier_summary <- barrier %>%
  group_by(age_grp, Highest_Challenge_Type) %>%
  summarise(Count = n(), .groups = 'drop') %>%
  group_by(age_grp) %>%
  mutate(Percentage = (Count / sum(Count)) * 100)

# Create a bar graph of challenge percentages by age group with custom colors
ggplot(barrier_summary, aes(x = age_grp, y = Percentage, fill = Highest_Challenge_Type)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(
    title = "Percentage Distribution of Highest Challenges by Age Group",
    x = "Age Group",
    y = "Percentage of Challenges",
    fill = "Challenge Type"
  ) +
  theme_minimal() +
  scale_fill_manual(values = c("Physical" = "#FF9999",   # Light Red
                               "Trust" = "#99CCFF",     # Light Blue
                               "Knowledge" = "#99FF99") # Light Green
  ) +
  theme(
    plot.title = element_text(hjust = 0.5),  # Center the title
    legend.position = "top"                   # Position the legend at the top
  )
