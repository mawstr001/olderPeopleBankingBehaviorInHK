
# Load necessary libraries
library(dplyr)
library(ggplot2)

intro_info <- banking_usage_no_row2_master0429 %>%
  select(Age, Owns_mobile, Employment_status, Highest_education, Tech_self_assessment, Rely_other_freq)



employment_dict <- data.frame(
  Digit = c(1,2,3,4,5),
  Description = c(
    "Employed",
    "Retired",
    "Unemployed",
    "Full-time homemaker",
    "Owning your own firm"
  )
)

education_dict <- data.frame(
  Digit = c(1,2,3,4,5,6,7，8),
  Description = c(
    "Primary",
    "Middle School",
    "High School",
    "Bachelor",
    "Masters",
    "Doctorate",
    "None of the above"
  )
)

intro_info$Highest_education <- as.numeric(as.character(intro_info$Highest_education))
# Merge counts with the complete set of descriptions
# Merge demographic with the gender dictionary
edu_table <- intro_info %>%
  left_join(education_dict, by = c("Highest_education" = "Digit")) %>%
  select(Age, Description)  # Select relevant columns

employment_counts <- edu_table %>%
  group_by(Description) %>%
  summarise(Count = n()) %>%
  ungroup()

# Calculate total count for percentage calculation
total_count <- sum(employment_counts$Count)

# Calculate percentage for each age group
employment_percentage <- employment_counts %>%
  mutate(Percentage = (Count / total_count) * 100)

# Print the age group percentage table
print(employment_percentage)

# Create a bar chart
ggplot(employment_percentage, aes(x = Description, y = Percentage, fill = Description)) +
  geom_bar(stat = "identity") +
  labs(title = "Employment Status Percentage",
       x = "Employment Status",
       y = "Percentage (%)") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
