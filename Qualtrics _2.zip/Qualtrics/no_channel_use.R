# Load necessary libraries
library(ggplot2)
library(dplyr)
library(tidyr)

# Step 1: Load the dataset
# banking_usage_no_row2_master0429 <- read.csv('your_data.csv')

# Step 2: Select relevant columns
number_of_channel_use <- banking_usage_no_row2_master0429 %>%
  select(Response.ID, 
         Num_branch_use_last_year, 
         Num_digital_use_last_year, 
         Num_atm_use_last_year, 
         Num_tel_use_last_year)

# Reshape the data to long format
number_of_channel_use <- number_of_channel_use %>%
  pivot_longer(cols = c(Num_branch_use_last_year, 
                        Num_digital_use_last_year, 
                        Num_atm_use_last_year, 
                        Num_tel_use_last_year),
               names_to = "Channel",
               values_to = "Frequency") %>%
  mutate(Channel = recode(Channel,
                          `Num_branch_use_last_year` = "Branch",
                          `Num_digital_use_last_year` = "Digital",
                          `Num_atm_use_last_year` = "ATM",
                          `Num_tel_use_last_year` = "Phone Banking"),
         Frequency = recode(Frequency,
                            `1` = 0,          # 0 times
                            `2` = 1,        # 1-5 times
                            `3` = 1))       # 6 times or more

# Step 3: Group by Response ID and Channel, then count Yes and No responses
summary_data <- number_of_channel_use %>%
  group_by(Response.ID, Channel) %>%
  summarise(Count_No = sum(Frequency == "No"),
            Count_Yes = sum(Frequency == "Yes"), 
            .groups = 'drop') %>%
  pivot_longer(cols = starts_with("Count_"),
               names_to = "Response",
               values_to = "Count") %>%
  mutate(Response = recode(Response,
                           `Count_No` = "No",
                           `Count_Yes` = "Yes"))

# Step 4: Create the bar graph
ggplot(summary_data, aes(x = Channel, y = Count, fill = Response)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Branch Usage Responses by Channel",
       x = "Banking Channel",
       y = "Number of Respondents") +
  theme_minimal()
