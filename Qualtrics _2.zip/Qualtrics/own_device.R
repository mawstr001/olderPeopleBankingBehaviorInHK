result_table_subset

own_device <- result_table_subset %>%
  mutate(Q5 = ifelse(Q5 == "是", "Yes", "No")) %>%  # Change labels here
  group_by(Q5) %>%
  summarise(Count = n(), .groups = "drop")


# Create the pie chart using ggplot2
ggplot(own_device, aes(x = "", y = Count, fill = Q5)) +
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +  # Convert to pie chart
  theme_void() +  # Remove background and grid
  labs(fill = "Device Own (N=152)")  # Change legend title to "Own Device"
