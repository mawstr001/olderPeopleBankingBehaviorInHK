# Load necessary library
library(dplyr)


# Assuming result_table_subset is defined and contains Q1 and Q2
# Summarize counts by Age (Q1) and Gender (Q2)
population_summary <- result_table_subset %>%
  group_by(Q1, Q2) %>%
  summarise(Count = n(), .groups = "drop")

# Negate counts for males to create the pyramid effect
population_summary <- population_summary %>%
  mutate(Count = ifelse(Q2 == "男性", -Count, Count))

# Create the population pyramid with custom colors
ggplot(population_summary, aes(x = Q1, y = Count, fill = Q2)) +
  geom_bar(stat = "identity", position = "identity") +
  coord_flip() +  # Flip coordinates for pyramid effect
  scale_y_continuous(labels = abs) +  # Display positive values on y-axis
  scale_fill_manual(values = c("男性" = "blue", "女性" = "red")) +  # Custom colors
  labs(title = "Population Pyramid", 
       x = "Age", 
       y = "Population Count") +
  theme_minimal() +
  theme(legend.title = element_blank())

